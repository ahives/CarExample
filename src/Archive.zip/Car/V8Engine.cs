namespace Car
{
    public class V8Engine :
        IEngine
    {
        public EngineType Engine() => EngineType.V8;
    }
}