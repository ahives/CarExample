namespace Car
{
    public class V12Engine : IEngine
    {
        public EngineType Engine() => EngineType.V12;
    }
}