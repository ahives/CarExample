namespace Car
{
    public enum EngineType
    {
        V8,
        V12,
        NA
    }
}