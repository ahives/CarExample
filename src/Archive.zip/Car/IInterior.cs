namespace Car
{
    public interface IInterior
    {
        bool HasRadio();
    }
}