namespace Car
{
    public interface IEngine
    {
        EngineType Engine();
    }
}